# TunaAppDocker
Goto TunaAppDocker/Tuna-HyperledgerFabric/
Run ./startFabric.sh

1) Pull Hyperledger Fabric, MongoDB and customised Tuna DApp Images from Docker hub.
2) Browse http://locallhost/5000 and play with it.
3) More navigation steps of application check https://medium.com/@vamsi.engr/hyperledger-fabric-with-authentication-page-ace28c18a5f4
