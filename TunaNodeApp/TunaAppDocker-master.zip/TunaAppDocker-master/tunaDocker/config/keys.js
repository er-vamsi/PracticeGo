module.exports = {
    'MongoURI' : 'mongodb://mongo:27017/tuna'
}